const Influx = require('influx');

const AWS = require("aws-sdk");
const dynamodb = new AWS.DynamoDB();

//This code writes data from IoT core rule via Lambda into InfluxDB
//It checks the incoming messages for deviceid and clientid
//Any metadata associated with these items are added to the messages

exports.handler = (event, context, callback) => {

    console.log(event);
    var pressureInputValue = JSON.parse(event.pressure);
    var viscosityInputValue = JSON.parse(event.viscosity);
    //Create clientID
    var clientid = JSON.stringify(event.clientid);
    var deviceid = JSON.stringify(event.deviceid);
    var sensorInputName = deviceid+clientid; 

    //var sensordatetime = JSON.stringify(event.sensordatetime);
    
    // Look for metadata in DynamoDB
    var params = { }
    params.TableName = process.env.DYNAMODB_TABLE;
    var key = { "metakey": {"S":event.deviceid} };
    params.Key = key;
    
    dynamodb.getItem(params, function(err, data) {
        var metadata={}

        if (err) console.log(err);
        else {console.log(data);metadata=data;}
        
        // write to influx regardless
        var result = writeToInfluxDB (pressureInputValue, viscosityInputValue,sensorInputName, JSON.stringify(metadata));
        callback(null, result);

    });
    

  };

function writeToInfluxDB(pressureVar, viscosityVar,sensorVar, metadata)
{
    console.log("Executing Iflux insert");

    const client = new Influx.InfluxDB({
        database: process.env.INFLUXDB,
        username: process.env.INFLUXDBUSRNAME,
        password: process.env.INFLUXDBPWD,
        port: process.env.INFLUXDBPORT,
        hosts: [{ host: process.env.INFLUXDBHOST }],
        schema: [{
            measurement: 'pressure',
    
            fields: {
                pressureValue: Influx.FieldType.FLOAT, 
                viscosity: Influx.FieldType.FLOAT,
            },
    
            tags: ['sensorID', 'metadata']
        }]
    });
    
    client.writePoints([{
        measurement: 'pressure', fields: { pressureValue: pressureVar, viscosity: viscosityVar},
        tags: { sensorID: sensorVar, metadata: metadata}
    }]) 
    console.log("Finished executing");
}  